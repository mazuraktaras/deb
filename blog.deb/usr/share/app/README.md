#### The simple blog API with JWT authentication, WEB frontend and blog bot
