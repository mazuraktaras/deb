#!/usr/bin/env bash

set -e -x

function golang {
cd /usr/share/app/
/usr/share/app/blog.py
}

function java {
ENV=$(aws ec2 describe-tags --filters "Name=resource-id,Values=$(curl -s http://169.254.169.254/latest/meta-data/instance-id)" --region  --query "Tags[?Key=='aws:autoscaling:groupName'].Value" --output text | cut -f2 -d"-")

# Running app with appropriate profiling group name.
/usr/bin/java -javaagent:/usr/share/app/codeguru-profiler-java-agent-standalone-0.3.2.jar="profilingGroupName:blog-${ENV}" -jar /usr/share/app/blog.py
}

function python {
  cd /usr/share/app/
  ./run.sh
}

lang=python
if [ $lang = "golang" ]; then
  golang
elif [ $lang = "java" ]; then
  java
elif [ $lang = "python" ]; then
  python
else
echo "This programming language isn't supported now"
fi
